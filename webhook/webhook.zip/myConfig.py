spotApi = "https://asia-east2-chatbot-108aea008.cloudfunctions.net/spot-"

orderApi = "https://asia-east2-chatbot-108aea008.cloudfunctions.net/order-"

userApi = "https://asia-east2-chatbot-108aea008.cloudfunctions.net/user-"
